"""UAV Strategy Engine package."""
